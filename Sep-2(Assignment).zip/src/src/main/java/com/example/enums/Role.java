package com.example.enums;

public enum Role {

    EMPLOYEE,
    CUSTOMER,
    ADMIN
}


