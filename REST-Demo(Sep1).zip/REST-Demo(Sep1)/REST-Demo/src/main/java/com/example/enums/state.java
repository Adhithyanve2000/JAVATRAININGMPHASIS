package com.example.enums;

public class state {

}
